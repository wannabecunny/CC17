// XML Layout remains the same as before

// MainActivity.kt
package com.example.cc17

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class login : AppCompatActivity() {

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginButton: Button
    private lateinit var forgotPasswordLink: TextView
    private lateinit var googleButton: ImageView
    private lateinit var facebookButton: ImageView
    private lateinit var appleButton: ImageView
    //private lateinit var emergencyCallButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        // Initialize views
        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginButton = findViewById(R.id.login_button)
        forgotPasswordLink = findViewById(R.id.forgotPasswordLink)
        googleButton = findViewById(R.id.goButton)
        facebookButton = findViewById(R.id.fbButton)
        appleButton = findViewById(R.id.appleButton)

        // Set click listeners
        loginButton.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()

            if (validateInput(username, password)) {
                performLogin(username, password)
            }
        }

        forgotPasswordLink.setOnClickListener {
            // Navigate to forgot password screen
            startForgotPasswordFlow()
        }

        googleButton.setOnClickListener {
            // Implement Google Sign In
            signInWithGoogle()
        }

        facebookButton.setOnClickListener {
            // Implement Facebook Sign In
            signInWithFacebook()
        }

        appleButton.setOnClickListener {
            // Implement Apple Sign In
            signInWithApple()
        }

//        emergencyCallButton.setOnClickListener {
//            Make emergency call
//            makeEmergencyCall()
//        }
    }

    private fun validateInput(username: String, password: String): Boolean {
        if (username.isEmpty()) {
            usernameInput.error = "Username cannot be empty"
            return false
        }
        if (password.isEmpty()) {
            passwordInput.error = "Password cannot be empty"
            return false
        }
        return true
    }

    private fun performLogin(username: String, password: String) {
        // Implement your login logic here
        // This could involve calling an API, checking local database, etc.
    }

    private fun startForgotPasswordFlow() {
        // Navigate to forgot password screen
        // Example:
        // startActivity(Intent(this, ForgotPasswordActivity::class.java))
    }

    private fun signInWithGoogle() {
        // Implement Google Sign In
        // This would typically use Firebase Auth or Google Sign In API
    }

    private fun signInWithFacebook() {
        // Implement Facebook Sign In
        // This would typically use Facebook SDK
    }

    private fun signInWithApple() {
        // Implement Apple Sign In
        // This would typically use Apple Sign In API
    }

}